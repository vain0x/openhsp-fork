
//
//	hsp3gr.cpp header
//
#ifndef __hsp3gr_win_h
#define __hsp3gr_win_h

#include "../hsp3struct.h"

void hsp3typeinit_cl_extcmd( HSP3TYPEINFO *info );
void hsp3typeinit_cl_extfunc( HSP3TYPEINFO *info );

void hsp3gr_dbg_gui( void );

#endif
