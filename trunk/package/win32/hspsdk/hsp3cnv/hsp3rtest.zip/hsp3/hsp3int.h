
//
//	hsp3int.cpp header
//
#ifndef __hsp3int_h
#define __hsp3int_h

#include "hsp3struct.h"

void hsp3typeinit_intcmd( HSP3TYPEINFO *info );
void hsp3typeinit_intfunc( HSP3TYPEINFO *info );

#endif
