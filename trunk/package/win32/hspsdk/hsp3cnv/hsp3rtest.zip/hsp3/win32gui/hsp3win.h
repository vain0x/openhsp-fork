
//
//	hsp3win.cpp header
//
#ifndef __hsp3win_h
#define __hsp3win_h

int hsp3win_exec( void );
int hsp3win_init( HINSTANCE hInstance, char *startfile );
void hsp3win_dialog( char *mes );

#endif
