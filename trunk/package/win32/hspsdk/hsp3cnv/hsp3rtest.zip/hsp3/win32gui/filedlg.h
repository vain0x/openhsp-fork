
//		in filedlg.cpp functions

BOOL fd_dialog( HWND hwnd, int mode, char *fext, char *finf );
char *fd_getfname( void );
DWORD fd_selcolor( HWND hwnd, int mode );

