
//
//	hspvar_label.cpp header
//
#ifndef __hspvar_label_h
#define __hspvar_label_h

#include "hspvar_core.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned short *HSPVAR_LABEL;
void HspVarLabel_Init( HspVarProc *p );

#ifdef __cplusplus
}
#endif

#endif
