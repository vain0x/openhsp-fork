//
//	hsp3cnv generated source
//	[test.ax]
//
#include "hsp3r.h"

#define _HSP3CNV_DATE "2011/07/26"
#define _HSP3CNV_TIME "12:40:42"
#define _HSP3CNV_MAXVAR 0
#define _HSP3CNV_MAXHPI 0
#define _HSP3CNV_VERSION 0x301
#define _HSP3CNV_BOOTOPT 0

/*-----------------------------------------------------------*/


/*-----------------------------------------------------------*/

void __HspEntry( void ) {
	// Var initalize

	// mes "����ɂ��́["
	PushStr("����ɂ��́["); 
	Extcmd(15,1);
	TaskSwitch(0);
}

static void L0000( void ) {
	// stop 
	Prgcmd(17,0);
	return;
	// goto *L0000
	TaskSwitch(0);
	return;
	TaskSwitch(1);
}

static void L0001( void ) {
	// stop 
	Prgcmd(17,0);
	return;
	// goto 
	Prgcmd(0,0);
	return;
}

//-End of Source-------------------------------------------

CHSP3_TASK __HspTaskFunc[]={
(CHSP3_TASK) L0000,
(CHSP3_TASK) L0001,

};

/*-----------------------------------------------------------*/


/*-----------------------------------------------------------*/

void __HspInit( Hsp3r *hsp3 ) {
	hsp3->Reset( _HSP3CNV_MAXVAR, _HSP3CNV_MAXHPI );
	hsp3->SetDataName( 0 );
	hsp3->SetFInfo( 0, 0 );
	hsp3->SetLInfo( 0, 0 );
	hsp3->SetMInfo( 0, 0 );
}

/*-----------------------------------------------------------*/

