/*
 * $Id: Reference.java,v 1.2 2006/01/13 20:32:12 Yuki Exp $
 */
package hsplet.variable;

/**
 * �ʂ̃I�y�����h�̓���̃C���f�b�N�X���Q�Ƃ���I�y�����h��\���N���X�B
 * <p>
 * dup �œ���̔z��v�f�ɕϐ������蓖�Ă�ꂽ�ꍇ�ȂǂɎg�p����B
 * </p>
 * <p>
 * ���ׂĂ̌Ăяo���ɑ΂��ăx�[�X�C���f�b�N�X�̉��ʂ𗚂����ĎQ�Ɛ�ɏ������Ϗ�����B
 * </p>
 * 
 * @author Yuki
 * @version $Revision: 1.2 $, $Date: 2006/01/13 20:32:12 $
 */
public final class Reference extends Operand {

  /** ���񉻕������ɁA�f�[�^�̌݊������m�F���邽�߂̃o�[�W�����ԍ��B */
  private static final long serialVersionUID = -6159793912128847879L;

  /** ���̃N���X���܂ރ\�[�X�t�@�C���̃o�[�W����������B */
  private static final String fileVersionID = "$Id: Reference.java,v 1.2 2006/01/13 20:32:12 Yuki Exp $";

  /** �l��ێ�����I�u�W�F�N�g�B */
  private Operand value;

  /** �x�[�X�C���f�b�N�X�B */
  private int base;

  /**
   * �I�u�W�F�N�g���\�z����B
   * 
   * @param value �l��ێ�����I�u�W�F�N�g�B
   * @param base �I�u�W�F�N�g�̃x�[�X�C���f�b�N�X�B
   */
  public Reference(final Operand value, final int base) {

    this.value = value;
    this.base = base;
  }

  //@Override
  public int getType() {

    return value.getType();
  }

  //@Override
  public String toString(final int index) {

    return value.toString(index + base);
  }

  //@Override
  public ByteString toByteString(final int index) {

    return value.toByteString(index + base);
  }

  //@Override
  public int toInt(final int index) {

    return value.toInt(index + base);
  }

  //@Override
  public double toDouble(final int index) {

    return value.toDouble(index + base);
  }

  //@Override
  public int getIndex(final int i0, final int i1) {

    return value.getIndex(i0, i1);
  }

  //@Override
  public int getIndex(final int i0, final int i1, final int i2) {

    return value.getIndex(i0, i1, i2);
  }

  //@Override
  public int getIndex(final int i0, final int i1, final int i2, final int i3) {

    return value.getIndex(i0, i1, i2, i3);
  }

  //@Override
  public void inc(final int index) {

    value.inc(index + base);
  }

  //@Override
  public void dec(final int index) {

    value.inc(index + base);
  }

  //@Override
  public void assign(final int index, final Operand rhs, final int rhi) {

    value.assign(index + base, rhs, rhi);
  }

  //@Override
  public void assignAdd(final int index, final Operand rhs, final int rhi) {

    value.assignAdd(index + base, rhs, rhi);
  }

  //@Override
  public void assignSub(final int index, final Operand rhs, final int rhi) {

    value.assignSub(index + base, rhs, rhi);
  }

  //@Override
  public void assignMul(final int index, final Operand rhs, final int rhi) {

    value.assignMul(index + base, rhs, rhi);
  }

  //@Override
  public void assignDiv(final int index, final Operand rhs, final int rhi) {

    value.assignDiv(index + base, rhs, rhi);
  }

  //@Override
  public void assignMod(final int index, final Operand rhs, final int rhi) {

    value.assignMod(index + base, rhs, rhi);
  }

  //@Override
  public void assignAnd(final int index, final Operand rhs, final int rhi) {

    value.assignAnd(index + base, rhs, rhi);
  }

  //@Override
  public void assignOr(final int index, final Operand rhs, final int rhi) {

    value.assignOr(index + base, rhs, rhi);
  }

  //@Override
  public void assignXor(final int index, final Operand rhs, final int rhi) {

    value.assignXor(index + base, rhs, rhi);
  }

  //@Override
  public void assignSr(final int index, final Operand rhs, final int rhi) {

    value.assignSr(index + base, rhs, rhi);
  }

  //@Override
  public void assignSl(final int index, final Operand rhs, final int rhi) {

    value.assignSl(index + base, rhs, rhi);
  }

  //@Override
  public Operand eq(final int index, final Operand rhs, final int rhi) {

    return value.eq(index + base, rhs, rhi);
  }

  //@Override
  public Operand ne(final int index, final Operand rhs, final int rhi) {

    return value.ne(index + base, rhs, rhi);
  }

  //@Override
  public Operand gt(final int index, final Operand rhs, final int rhi) {

    return value.gt(index + base, rhs, rhi);
  }

  //@Override
  public Operand lt(final int index, final Operand rhs, final int rhi) {

    return value.lt(index + base, rhs, rhi);
  }

  //@Override
  public Operand ge(final int index, final Operand rhs, final int rhi) {

    return value.ge(index + base, rhs, rhi);
  }

  //@Override
  public Operand le(final int index, final Operand rhs, final int rhi) {

    return value.le(index + base, rhs, rhi);
  }

  //@Override
  public Operand add(final int index, final Operand rhs, final int rhi) {

    return value.add(index + base, rhs, rhi);
  }

  //@Override
  public Operand sub(final int index, final Operand rhs, final int rhi) {

    return value.sub(index + base, rhs, rhi);
  }

  //@Override
  public Operand mul(final int index, final Operand rhs, final int rhi) {

    return value.mul(index + base, rhs, rhi);
  }

  //@Override
  public Operand div(final int index, final Operand rhs, final int rhi) {

    return value.div(index + base, rhs, rhi);
  }

  //@Override
  public Operand mod(final int index, final Operand rhs, final int rhi) {

    return value.mod(index + base, rhs, rhi);
  }

  //@Override
  public Operand and(final int index, final Operand rhs, final int rhi) {

    return value.and(index + base, rhs, rhi);
  }

  //@Override
  public Operand or(final int index, final Operand rhs, final int rhi) {

    return value.or(index + base, rhs, rhi);
  }

  //@Override
  public Operand xor(final int index, final Operand rhs, final int rhi) {

    return value.xor(index + base, rhs, rhi);
  }

  //@Override
  public Operand sl(final int index, final Operand rhs, final int rhi) {

    return value.sl(index + base, rhs, rhi);
  }

  //@Override
  public Operand sr(final int index, final Operand rhs, final int rhi) {

    return value.sr(index + base, rhs, rhi);
  }

  //@Override
  public int l0() {

    return value.l0();
  }

  //@Override
  public int l1() {

    return value.l1();
  }

  //@Override
  public int l2() {

    return value.l2();
  }

  //@Override
  public int l3() {

    return value.l3();
  }

  //@Override
  public byte peek(int index, int offset) {

    return value.peek(index + base, offset);
  }

  //@Override
  public void poke(int index, int offset, byte value) {

    this.value.poke(index + base, offset, value);

  }

  //@Override
  public Operand ref(int index) {

    if (index == 0) {
      return this;
    } else {
      return new Reference(value, base + index);
    }
  }
}
